var iｉl = 'jsjiami.com.v6',
    iｉl_ = ['iｉl'],
    lIIIl1ll = [iｉl, '\x6f\x6b\x68\x74\x74\x70\x2f\x33\x2e\x31\x35', '\x69\x6e\x64\x65\x78\x4f\x66', '\x24\x24\x24', '\x73\x70\x6c\x69\x74', '\x74\x72\x69\x6d', '\x26\x26\x26', '\x3a\x2f\x2f', '\x6c\x6f\x67', '\x70\x69\x63\x55\x72\x6c\x3a\x20', '\x72\x65\x70\x6c\x61\x63\x65', '\x70\x75\x73\x68', '\x2f\x66\x69\x6c\x65\x2f\x6c\x69\x76\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74', '\x2f\x6c\x69\x76\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74', '\x47\x45\x54', '\x70\x61\x72\x73\x65', '\x63\x6f\x6e\x74\x65\x6e\x74', '\x73\x75\x62\x73\x74\x72\x69\x6e\x67', '\x6c\x61\x73\x74\x49\x6e\x64\x65\x78\x4f\x66', '\x6e\x61\x6d\x65', '\x75\x72\x6c', '\x3d\x3d\x3d\x3d\x20\x3e\x3e\x3e\x20', '\x73\x74\x72\x69\x6e\x67\x69\x66\x79', '\x65\x78\x65\x63', '\x74\x65\x73\x74', '\x6d\x61\x74\x63\x68', '\x63\x68\x61\x6e\x6e\x65\x6c', '\x2c\x23\x67\x65\x6e\x72\x65\x23\x0a', '\x75\x72\x6c\x73', '\x64\x61\x74\x61', '\x64\x61\x74\x61\x6c\x69\x73\x74', '\x70\x72\x6f\x76', '\x6c\x69\x73\x74', '\x2d\x2d\x2d', '\x6c\x69\x6e\x65', '\x77\x65\x62\x50\x69\x63\x55\x72\x6c\x3a\x20', '\x23\x45\x58\x54\x4d\x33\x55', '\x22\x63\x68\x61\x6e\x6e\x65\x6c\x22', '\x22\x75\x72\x6c\x73\x22', '\x22\x64\x61\x74\x61\x6c\x69\x73\x74\x22', '\x6c\x65\x6e\x67\x74\x68', '\x23\x67\x65\x6e\x72\x65\x23', '\x7b\x6e\x61\x6d\x65\x7d', '\x7b\x63\x61\x74\x65\x7d', '\u76f4\u64ad\u5217\u8868', '\x6e\x75\x6c\x6c', '\x74\x79\x70\x65\x5f\x69\x64', '\x76\x6f\x64\x5f\x70\x6c\x61\x79\x5f\x75\x72\x6c', '\x68\x61\x73\x4f\x77\x6e\x50\x72\x6f\x70\x65\x72\x74\x79', '\x6a\x6f\x69\x6e', '\x76\x6f\x64\x5f\x70\x6c\x61\x79\x5f\x66\x72\x6f\x6d', '\x6a\x43\x50\x73\x4e\x6a\x77\x69\x4a\x61\x51\x6d\x69\x2e\x63\x6f\x4e\x4f\x6d\x47\x72\x2e\x76\x56\x36\x41\x46\x67\x79\x74\x74\x3d\x3d'];

function Ii1l1III(_0x3b13df, _0x346a54) {
    _0x3b13df = ~~'0x' ['concat'](_0x3b13df['slice'](0x0));
    var _0x4db44b = lIIIl1ll[_0x3b13df];
    return _0x4db44b;
};
(function(_0x209161, _0x5eaa4a) {
    var _0x42ecdf = 0x0;
    for (_0x5eaa4a = _0x209161['shift'](_0x42ecdf >> 0x2); _0x5eaa4a && _0x5eaa4a !== (_0x209161['pop'](_0x42ecdf >> 0x3) + '')['replace'](/[CPNwJQNOGrVAFgytt=]/g, ''); _0x42ecdf++) {
        _0x42ecdf = _0x42ecdf ^ 0x127efd;
    }
}(lIIIl1ll, Ii1l1III));
let headers = {
    'User-Agent': Ii1l1III('0')
};
let classes = [];
let cates = {};
let picUrl = '';
let webPaths = {};

function init(IiIIi1i) {
    let i1Ii11I1 = '';
    if (IiIIi1i[Ii1l1III('1')](Ii1l1III('2')) > 0x0) {
        i1Ii11I1 = IiIIi1i[Ii1l1III('3')](Ii1l1III('2'))[0x0][Ii1l1III('4')]();
        IiIIi1i = IiIIi1i[Ii1l1III('3')](Ii1l1III('2'))[0x1][Ii1l1III('4')]();
    }
    if (IiIIi1i[Ii1l1III('1')](Ii1l1III('5')) > 0x0) {
        picUrl = IiIIi1i[Ii1l1III('3')](Ii1l1III('5'))[0x1][Ii1l1III('4')]();
        if (picUrl[Ii1l1III('1')](Ii1l1III('6')) < 0x0) {
            picUrl = i1Ii11I1 + picUrl;
        }
        IiIIi1i = IiIIi1i[Ii1l1III('3')](Ii1l1III('5'))[0x0][Ii1l1III('4')]();
    }
    console[Ii1l1III('7')](Ii1l1III('8') + picUrl);
    let IIlIlI1I = IiIIi1i[Ii1l1III('3')]('\x23');
    for (const IlII1I1 of IIlIlI1I) {
        if (IlII1I1[Ii1l1III('1')]('\x24') > 0x0) {
            let illIl111 = IlII1I1;
            let Ill1iIi = IlII1I1[Ii1l1III('3')]('\x24')[0x0];
            if (illIl111[Ii1l1III('1')](Ii1l1III('6')) < 0x0) {
                illIl111 = illIl111[Ii1l1III('9')]('\x24', '\x24' + i1Ii11I1);
            }
            classes[Ii1l1III('a')]({
                'type_id': illIl111,
                'type_name': Ill1iIi[Ii1l1III('9')]('\x21\x21', '')
            });
        } else {
            let II1lIlli = IlII1I1;
            if (II1lIlli[Ii1l1III('1')](Ii1l1III('6')) < 0x0) {
                II1lIlli = i1Ii11I1 + II1lIlli;
            }
            II1lIlli = II1lIlli[Ii1l1III('9')](Ii1l1III('b'), Ii1l1III('c'));
            let Illi11ll = req(II1lIlli, {
                '\x6d\x65\x74\x68\x6f\x64': Ii1l1III('d'),
                '\x68\x65\x61\x64\x65\x72\x73': headers
            });
            try {
                let l1lIiill = JSON[Ii1l1III('e')](Illi11ll[Ii1l1III('f')]);
                let lillI11l = II1lIlli[Ii1l1III('10')](0x0, II1lIlli[Ii1l1III('11')]('\x2f') + 0x1);
                for (const i1iilII1 of l1lIiill) {
                    let Iillil = i1iilII1[Ii1l1III('12')];
                    let lI1iIl = i1iilII1[Ii1l1III('13')];
                    let illIl111 = Iillil + '\x24' + (lI1iIl[Ii1l1III('1')](Ii1l1III('6')) < 0x0 ? lillI11l : '') + lI1iIl;
                    classes[Ii1l1III('a')]({
                        'type_id': illIl111,
                        'type_name': Iillil[Ii1l1III('9')]('\x21\x21', '')
                    });
                    webPaths[illIl111] = lillI11l;
                }
            } catch (Ii1Ii11) {
                console[Ii1l1III('7')](Ii1l1III('14') + Ii1Ii11);
            }
        }
    }
}

function home(I1iiIiIl) {
    return JSON[Ii1l1III('15')]({
        'class': classes,
        'filters': null
    });
}

function parseM3u(iIi1Ii1I, I1IlIIIi) {
    let iI1iiIii = {};
    let iiI11111 = /(#EXTINF:.+?),([^,]+?)\s*\n(.+?)\s*\n/g;
    let ii1iilil = null;
    while ((ii1iilil = iiI11111[Ii1l1III('16')](iIi1Ii1I)) != null) {
        let lllli1iI = ii1iilil[0x1];
        let il1Ili1I = ii1iilil[0x2];
        let liIlll1l = ii1iilil[0x3];
        if (il1Ili1I == null || liIlll1l == null || il1Ili1I == '' || liIlll1l == '') {
            continue;
        }
        il1Ili1I = il1Ili1I[Ii1l1III('4')]();
        liIlll1l = liIlll1l[Ii1l1III('4')]();
        let IiI1lI1l = I1IlIIIi;
        let ilIl1i1i = /group-title="(.*?)"/;
        if (ilIl1i1i[Ii1l1III('17')](lllli1iI)) {
            IiI1lI1l = lllli1iI[Ii1l1III('18')](ilIl1i1i)[0x1];
        }
        if (!iI1iiIii[IiI1lI1l]) {
            iI1iiIii[IiI1lI1l] = [];
        }
        iI1iiIii[IiI1lI1l][Ii1l1III('a')](il1Ili1I + '\x2c' + liIlll1l);
    }
    let ll11III1 = '';
    for (const li1Ili in iI1iiIii) {
        ll11III1 += li1Ili + '\x0a';
        let IlIil1ll = iI1iiIii[li1Ili];
        for (const li1iI11 of IlIil1ll) {
            ll11III1 += li1iI11 + '\x0a';
        }
    }
    return ll11III1;
}

function parseFm(IliiIl1I) {
    let lliiI1i1 = '';
    let Iii1ll = JSON[Ii1l1III('e')](IliiIl1I);
    for (const i1lIlli1 of Iii1ll) {
        let I111Il1l = i1lIlli1[Ii1l1III('12')];
        let ilI11li = i1lIlli1[Ii1l1III('19')];
        lliiI1i1 += I111Il1l + Ii1l1III('1a');
        for (const iiilI1iI of ilI11li) {
            let I11111l1 = iiilI1iI[Ii1l1III('12')];
            let IlI1l1I1 = iiilI1iI[Ii1l1III('1b')];
            for (const l1II1lll of IlI1l1I1) {
                lliiI1i1 += I11111l1 + '\x2c' + l1II1lll + '\x0a';
            }
        }
    }
    return lliiI1i1;
}

function parseLu(iIliI1lI) {
    let IIlilI1i = '';
    let I11ilI1i = JSON[Ii1l1III('e')](iIliI1lI)[Ii1l1III('1c')];
    for (const i1Ii1l1 of I11ilI1i[Ii1l1III('1d')]) {
        let I11111l = i1Ii1l1[Ii1l1III('1e')];
        let IiIiii1l = i1Ii1l1[Ii1l1III('1f')];
        IIlilI1i += I11111l + Ii1l1III('1a');
        for (const l1111lI of IiIiii1l) {
            let lIlI1iI = l1111lI[Ii1l1III('12')];
            let ll11i1II = l1111lI[Ii1l1III('1b')];
            for (const Iliilii of ll11i1II) {
                IIlilI1i += lIlI1iI + Ii1l1III('20') + Iliilii[Ii1l1III('21')] + '\x2c' + Iliilii[Ii1l1III('13')] + '\x0a';
            }
        }
    }
    return IIlilI1i;
}

function getCateData(IliI1i) {
    let iI1I1I1I = picUrl;
    if (IliI1i[Ii1l1III('1')](Ii1l1III('5')) > 0x0) {
        iI1I1I1I = IliI1i[Ii1l1III('3')](Ii1l1III('5'))[0x1][Ii1l1III('4')]();
        if (iI1I1I1I[Ii1l1III('1')](Ii1l1III('6')) < 0x0 && webPaths[IliI1i]) {
            iI1I1I1I = webPaths[IliI1i] + iI1I1I1I;
        }
        IliI1i = IliI1i[Ii1l1III('3')](Ii1l1III('5'))[0x0][Ii1l1III('4')]();
    }
    console[Ii1l1III('7')](Ii1l1III('22') + iI1I1I1I);
    let ll1iIiiI = IliI1i[Ii1l1III('3')]('\x24')[0x1];
    let i1I1l1i = IliI1i[Ii1l1III('3')]('\x24')[0x0];
    if (!cates[IliI1i]) {
        cates[IliI1i] = [];
        let iIl11Iii = headers;
        if (ll1iIiiI[Ii1l1III('1')]('\x7c') > 0x0) {
            let ii111I1I = decodeURIComponent(ll1iIiiI[Ii1l1III('3')]('\x7c')[0x1]);
            ll1iIiiI = ll1iIiiI[Ii1l1III('3')]('\x7c')[0x0];
            for (const II1Ii1l of ii111I1I[Ii1l1III('3')]('\x26')) {
                if (II1Ii1l[Ii1l1III('1')]('\x3d') > 0x0) {
                    let lI1lliii = II1Ii1l[Ii1l1III('3')]('\x3d')[0x0];
                    let I11Iii1i = II1Ii1l[Ii1l1III('3')]('\x3d')[0x1];
                    iIl11Iii[lI1lliii] = I11Iii1i;
                }
            }
        }
        let I111lilI = req(ll1iIiiI, {
            '\x6d\x65\x74\x68\x6f\x64': Ii1l1III('d'),
            '\x68\x65\x61\x64\x65\x72\x73': iIl11Iii
        });
        I111lilI = I111lilI[Ii1l1III('f')][Ii1l1III('4')]();
        if (I111lilI[Ii1l1III('1')](Ii1l1III('23')) >= 0x0) {
            I111lilI = parseM3u(I111lilI, i1I1l1i);
        } else if (I111lilI[Ii1l1III('1')](Ii1l1III('24')) > 0x0 && I111lilI[Ii1l1III('1')](Ii1l1III('25')) > 0x0) {
            I111lilI = parseFm(I111lilI);
        } else if (I111lilI[Ii1l1III('1')](Ii1l1III('26')) > 0x0 && I111lilI[Ii1l1III('1')](Ii1l1III('25')) > 0x0) {
            I111lilI = parseLu(I111lilI);
        }
        let li1IiiII = (i1I1l1i + '\x0a' + I111lilI[Ii1l1III('9')]('\x0d', ''))[Ii1l1III('3')]('\x0a');
        let lli11iI = i1I1l1i;
        let IiiIIiIi = null;
        let iiiI1l = '';
        for (let i1ii1IIl = 0x0; i1ii1IIl < li1IiiII[Ii1l1III('27')]; i1ii1IIl++) {
            let lIliIii = li1IiiII[i1ii1IIl][Ii1l1III('9')](/\s+/g, '');
            if (lIliIii != '' && lIliIii[Ii1l1III('1')](Ii1l1III('6')) < 0x0 && (lIliIii[Ii1l1III('1')]('\x2c') < 0x0 || lIliIii[Ii1l1III('1')](Ii1l1III('28')) > 0x0)) {
                if (iiiI1l != '') {
                    let ilIIIl = iI1I1I1I[Ii1l1III('9')](Ii1l1III('29'), encodeURIComponent(lli11iI))[Ii1l1III('9')](Ii1l1III('2a'), encodeURIComponent(i1I1l1i));
                    let ilI1ilI = ilIIIl[Ii1l1III('1')]('\x3c');
                    let iili1I1i = ilIIIl[Ii1l1III('11')]('\x3e');
                    if (ilI1ilI > -0x1 && iili1I1i > ilI1ilI) {
                        let I11Ilili = ilIIIl[Ii1l1III('10')](ilI1ilI, iili1I1i + 0x1);
                        let I1liliII = new RegExp(I11Ilili[Ii1l1III('9')](/<|>/g, ''));
                        let lii11liI = lli11iI[Ii1l1III('9')](I1liliII, function(Ili1lIi1, iiliII1l) {
                            return iiliII1l;
                        });
                        ilIIIl = ilIIIl[Ii1l1III('9')](I11Ilili, lii11liI);
                        console[Ii1l1III('7')](lli11iI + '\x2c\x20' + ilIIIl);
                    }
                    let IiiIIiIi = {
                        'vod_id': IliI1i + Ii1l1III('2') + cates[IliI1i][Ii1l1III('27')],
                        'vod_name': lli11iI,
                        'vod_pic': ilIIIl,
                        'vod_remarks': '',
                        'type_name': Ii1l1III('2b'),
                        'vod_year': '',
                        'vod_area': '',
                        'vod_actor': '',
                        'vod_director': '',
                        'vod_content': '',
                        'vod_play_from': i1I1l1i,
                        'vod_play_url': iiiI1l
                    };
                    cates[IliI1i][Ii1l1III('a')](IiiIIiIi);
                }
                lli11iI = lIliIii[Ii1l1III('3')]('\x2c')[0x0][Ii1l1III('4')]();
                iiiI1l = '';
            } else if (lIliIii[Ii1l1III('1')]('\x2c') > 0x0 && /http|rtmp|rtsp|rsp/ [Ii1l1III('17')](lIliIii)) {
                let l1iiI1ii = lIliIii[Ii1l1III('3')]('\x2c');
                if (iiiI1l != '') {
                    iiiI1l += '\x23';
                }
                iiiI1l += l1iiI1ii[0x0][Ii1l1III('4')]() + '\x24' + l1iiI1ii[0x1][Ii1l1III('4')]();
            }
        }
        if (iiiI1l != '') {
            let II1Iliil = iI1I1I1I[Ii1l1III('9')](Ii1l1III('29'), encodeURIComponent(lli11iI))[Ii1l1III('9')](Ii1l1III('2a'), encodeURIComponent(i1I1l1i));
            let ilI1ilI = II1Iliil[Ii1l1III('1')]('\x3c');
            let iili1I1i = II1Iliil[Ii1l1III('11')]('\x3e');
            if (ilI1ilI > -0x1 && iili1I1i > ilI1ilI) {
                let I11Ilili = II1Iliil[Ii1l1III('10')](ilI1ilI, iili1I1i + 0x1);
                let I1liliII = new RegExp(I11Ilili[Ii1l1III('9')](/<|>/g, ''));
                let lii11liI = I1liliII[Ii1l1III('17')](lli11iI) ? lli11iI[Ii1l1III('18')](I1liliII)[0x1] : Ii1l1III('2c');
                II1Iliil = II1Iliil[Ii1l1III('9')](I11Ilili, lii11liI);
            }
            let IiiIIiIi = {
                'vod_id': IliI1i + Ii1l1III('2') + cates[IliI1i][Ii1l1III('27')],
                'vod_name': lli11iI,
                'vod_pic': II1Iliil,
                'vod_remarks': '',
                'type_name': Ii1l1III('2b'),
                'vod_year': '',
                'vod_area': '',
                'vod_actor': '',
                'vod_director': '',
                'vod_content': '',
                'vod_play_from': i1I1l1i,
                'vod_play_url': iiiI1l
            };
            cates[IliI1i][Ii1l1III('a')](IiiIIiIi);
        }
    }
    return cates[IliI1i];
}

function homeVod(liIIlIl1) {
    let iIl1IIii = getCateData(classes[0x0][Ii1l1III('2d')]);
    let I1l1iil = JSON[Ii1l1III('15')]({
        'list': iIl1IIii
    });
    return I1l1iil;
}

function category(I1l1i1Ii, l1IiiIli, IIi1Illi, lilIliIl) {
    let IIi1i1ll = [];
    if (l1IiiIli == 0x1) {
        IIi1i1ll = getCateData(I1l1i1Ii);
    }
    let iIiiIi1i = JSON[Ii1l1III('15')]({
        'list': IIi1i1ll
    });
    return iIiiIi1i;
}

function detail(lIl11iii) {
    let I1IIIil = lIl11iii[Ii1l1III('3')](Ii1l1III('2'));
    let liiiil1i = I1IIIil[0x0];
    let l1l111II = liiiil1i[Ii1l1III('3')]('\x24')[0x0];
    let Il1li11i = parseInt(I1IIIil[0x1]);
    let Iill11Ii = getCateData(liiiil1i)[Il1li11i];
    console[Ii1l1III('7')](JSON[Ii1l1III('15')](Iill11Ii));
    if (l1l111II[Ii1l1III('1')]('\x21\x21') >= 0x0) {
        l1l111II = l1l111II[Ii1l1III('9')]('\x21\x21', '');
        const ii1l1iil = Iill11Ii[Ii1l1III('2e')][Ii1l1III('3')]('\x23');
        console[Ii1l1III('7')](JSON[Ii1l1III('15')](ii1l1iil));
        let i1Ili1I = {};
        let IIIllli1 = {};
        for (const i1IiIlIl of ii1l1iil) {
            let Ill1iii1 = i1IiIlIl[Ii1l1III('3')]('\x24')[0x0];
            let IIiIII11 = l1l111II;
            if (Ill1iii1[Ii1l1III('1')](Ii1l1III('20')) > 0x0) {
                IIiIII11 = Ill1iii1[Ii1l1III('3')](Ii1l1III('20'))[0x1];
                Ill1iii1 = Ill1iii1[Ii1l1III('3')](Ii1l1III('20'))[0x0];
            }
            if (!i1Ili1I[Ii1l1III('2f')](Ill1iii1)) {
                i1Ili1I[Ill1iii1] = 0x1;
            } else {
                i1Ili1I[Ill1iii1]++;
            }
            IIiIII11 = l1l111II + (i1Ili1I[Ill1iii1] > 0x1 ? '\x20' + i1Ili1I[Ill1iii1] : '');
            if (!IIIllli1[Ii1l1III('2f')](IIiIII11)) {
                IIIllli1[IIiIII11] = [];
            }
            IIIllli1[IIiIII11][Ii1l1III('a')](Ill1iii1 + '\x24' + i1IiIlIl[Ii1l1III('3')]('\x24')[0x1]);
        }
        let III1i1ii = [];
        let iii1lIIi = [];
        for (let iliI1I1i in IIIllli1) {
            III1i1ii[Ii1l1III('a')](iliI1I1i);
            iii1lIIi[Ii1l1III('a')](IIIllli1[iliI1I1i][Ii1l1III('30')]('\x23'));
        }
        Iill11Ii[Ii1l1III('31')] = III1i1ii[Ii1l1III('30')](Ii1l1III('2'));
        Iill11Ii[Ii1l1III('2e')] = iii1lIIi[Ii1l1III('30')](Ii1l1III('2'));
    }
    return JSON[Ii1l1III('15')]({
        'list': [Iill11Ii]
    });
}

function play(l1llIIii, illiiIII, lIIIiIiI) {
    return JSON[Ii1l1III('15')]({
        'parse': 0x0,
        'url': illiiIII
    });
}

function search(I1lll, lI1iiIII) {
    return null;
}
__JS_SPIDER__ = {
    '\x69\x6e\x69\x74': init,
    '\x68\x6f\x6d\x65': home,
    '\x68\x6f\x6d\x65\x56\x6f\x64': homeVod,
    '\x63\x61\x74\x65\x67\x6f\x72\x79': category,
    '\x64\x65\x74\x61\x69\x6c': detail,
    '\x70\x6c\x61\x79': play,
    '\x73\x65\x61\x72\x63\x68': search
};;
iｉl = 'jsjiami.com.v6';